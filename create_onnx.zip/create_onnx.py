import os
import shutil
import argparse
import time
import json
from datetime import datetime
from collections import defaultdict
from itertools import islice
import pickle
import copy

import numpy as np
import cv2

import torch
from torch import nn
from torch import autograd
import torch.nn.functional as F
import torch.optim as optim
from torch.nn.parallel import DistributedDataParallel

from tensorboardX import SummaryWriter

from mvn.utils import img, multiview, op, vis, misc, cfg
from mvn.datasets import human36m
from mvn.utils.multiview import Camera

from mvn.utils.img import resize_image, crop_image, normalize_image, image_batch_to_torch

#from detectron2_util import Detectron2util
from CameraCalibration import ArucoCalibrator

import torch.onnx
import onnx
import onnxruntime

from mvn.models.triangulation2 import VolumetricTriangulationNet2
from mvn.models.algPose2d import BaselinePose2d
from mvn.models.algPose2dwithConfidence import AlgebraicTriangulationNet2
from mvn.models.volPose2dFeatureOnly import VolPose2dFeatureOnly
#from mvn.models.volPose2dSpine2dAndFeatures import VolPose2dSpine2dAndFeatures
from mvn.models.algPose3dTriangulation import AlgPose3dTriangulation
from mvn.models.volPose3d import VolPose3d

def createCoordinateVolume(batch_size = 2, volume_size = 64, device='cpu', base_point=[0,0,0], cuboid_side=2500):

    coord_volumes = torch.zeros(batch_size, volume_size, volume_size, volume_size, 3, device=device) # Bx64x64x64x3
    for batch_i in range(batch_size):

        #keypoints_3d = keypoints_3d_Alg[0].to('cpu').detach().numpy().copy()
        #base_point = keypoints_3d[6, :3]

        # build cuboid
        sides = np.array([cuboid_side, cuboid_side, cuboid_side])
        position = base_point - sides / 2

        # build coord volume
        xxx, yyy, zzz = torch.meshgrid(torch.arange(volume_size, device=device), torch.arange(volume_size, device=device), torch.arange(volume_size, device=device))
        grid = torch.stack([xxx, yyy, zzz], dim=-1).type(torch.float)
        grid = grid.reshape((-1, 3))

        grid_coord = torch.zeros_like(grid)
        grid_coord[:, 0] = position[0] + (sides[0] / (volume_size - 1)) * grid[:, 0]
        grid_coord[:, 1] = position[1] + (sides[1] / (volume_size - 1)) * grid[:, 1]
        grid_coord[:, 2] = position[2] + (sides[2] / (volume_size - 1)) * grid[:, 2]

        coord_volumes[batch_i] = grid_coord.reshape(volume_size, volume_size, volume_size, 3)

    return coord_volumes;

def main():
    #device = torch.device('cpu') 
    device = torch.device('cuda') 

    config = cfg.load_config("experiments/human36m/eval/human36m_vol_softmax.yaml")
    #config = cfg.load_config("experiments/human36m/eval/human36m_alg.yaml")

    #model = VolumetricTriangulationNet2(config, device=device).to(device)
    #model = BaselinePose2d(config, device=device).to(device)
    #model = AlgebraicTriangulationNet2(config, device=device).to(device)
    #model = VolPose2dFeatureOnly(config, device=device).to(device)
    #model = VolPose2dSpine2dAndFeatures(config, device=device).to(device)
    #model = AlgPose3dTriangulation(config, device=device).to(device)
    model = VolPose3d(config, device=device).to(device)
    
    if config.model.init_weights:
        if device == 'cpu':
            state_dict = torch.load(config.model.checkpoint, map_location='cpu') 
        else:
            state_dict = torch.load(config.model.checkpoint) 
        for key in list(state_dict.keys()):
            new_key = key.replace("module.", "")
            state_dict[new_key] = state_dict.pop(key)

        model.load_state_dict(state_dict, strict=True)
        print("Successfully loaded pretrained weights for whole model")
    model.eval()

    #input_image = torch.rand(2, 2, 3, 384, 384).cpu() #.cpu() .cuda()
    #input_projMat = torch.rand(2, 2, 3, 4).cpu() #.cpu() .cuda()

    #input = torch.rand(1, 3, 384, 384).to(device)

    #input_projMat = torch.rand(2, 3, 4).to(device)
    #input_2dpoints = torch.rand(2, 2).to(device)
    #input_confidence = torch.rand(2).to(device)

    input_volumes = torch.rand(1, 32,64,64,64).to(device)
    input_coords = createCoordinateVolume(batch_size=1, device=device)

    ##########################################
    ######## V2V ########### 
    ### VolPose3d
    ## →　TracerWarning: Converting a tensor to a Python integer might cause the trace to be incorrect. We can't record the data flow of Python values, so this value will be treated as a constant in the future. This means that the trace might not generalize to other inputs!
    ## 警告出たのでうまくできているのかわからん
    ##########################################   
    ### Export the model
    torch.onnx.export(model,               # model being run
                      (input_volumes, input_coords),                         # model input (or a tuple for multiple inputs)
                      "v2v_b1.onnx",   # where to save the model (can be a file or file-like object)
                      export_params=True,        # store the trained parameter weights inside the model file
                      opset_version=12,          # the ONNX version to export the model to
                      do_constant_folding=True,  # whether to execute constant folding for optimization
                      input_names = ['volumes', 'coords'],   # the model's input names
                      output_names = ['3dPoints'], # the model's output names
                      dynamic_axes={'volumes' : {0 : 'batch_size'},  #[1, 32, 64, 64, 64] unproject_heatmapをした後のもの
                                    'coords' : {0 : 'batch_size'},   #[n, 64, 64, 64, 3] いわゆるmeshgrid
                                    '3dPoints' : {0 : 'batch_size'}, #[n, 17, 3]
                                    })
    onnx_model = onnx.load("v2v_b1.onnx")
    onnx.checker.check_model(onnx_model)

    ##########################################
    ######## Algebraric trianglation ########### Exporting the operator svd to ONNX opset version 12 is not supported.ってことでダメでした
    ### AlgPose3dTriangulation
    ##########################################   
    ### Export the model
    #torch.onnx.export(model,               # model being run
    #                  (input_projMat, input_2dpoints,input_confidence),                         # model input (or a tuple for multiple inputs)
    #                  "alg_triangulation.onnx",   # where to save the model (can be a file or file-like object)
    #                  export_params=True,        # store the trained parameter weights inside the model file
    #                  opset_version=12,          # the ONNX version to export the model to
    #                  do_constant_folding=True,  # whether to execute constant folding for optimization
    #                  input_names = ['projMats', '2dPoints', 'confidences'],   # the model's input names
    #                  output_names = ['3dPoints'], # the model's output names
    #                  dynamic_axes={'projMats' : {0 : 'batch_size'},    # variable lenght axes これで入出力するTensorのdim=0が可変になる。それ以外の次元は固定
    #                                '2dPoints' : {0 : 'batch_size'},
    #                                'confidences' : {0 : 'batch_size'},
    #                                '3dPoints' : {0 : 'batch_size'},
    #                                })
    #onnx_model = onnx.load("alg_triangulation.onnx")
    #onnx.checker.check_model(onnx_model)

    #########################################
    ####### BackboneからFeaturesだけ出力するやつ. featuresへの後処理process_featuresも行って、[n, 32, 96, 96]を出力 + SpineのAlg2Dも計算する ##########
    ## →　TracerWarning: Converting a tensor to a Python integer might cause the trace to be incorrect. We can't record the data flow of Python values, so this value will be treated as a constant in the future. This means that the trace might not generalize to other inputs!
    ## 警告出たのでうまくできているのかわからん
    ## VolPose2dSpine2dAndFeatures
    #########################################   
    ## Export the model
    #torch.onnx.export(model,               # model being run
    #                  input,                         # model input (or a tuple for multiple inputs)
    #                  "baseline_pose2d_vol_spineAndfeatures.onnx",   # where to save the model (can be a file or file-like object)
    #                  export_params=True,        # store the trained parameter weights inside the model file
    #                  opset_version=10,          # the ONNX version to export the model to
    #                  do_constant_folding=True,  # whether to execute constant folding for optimization
    #                  input_names = ['input'],   # the model's input names
    #                  output_names = ['jointSpine2d', 'features'], # the model's output names
    #                  dynamic_axes={'input' : {0 : 'batch_size'},    # variable lenght axes これで入出力するTensorのdim=0が可変になる。それ以外の次元は固定
    #                                'jointSpine2d' : {0 : 'batch_size'},          #[n, 1, 2] Backboneの出力の6番目のHeatmap（Spine）を2d keypointまで計算したもの
    #                                'features' : {0 : 'batch_size'},          #[n, 32, 96, 96]
    #                                })
    #onnx_model = onnx.load("baseline_pose2d_vol_spineAndfeatures.onnx")
    #onnx.checker.check_model(onnx_model)

    ########################################
    ###### BackboneからFeaturesだけ出力するやつ. featuresへの後処理process_featuresも行って、[n, 32, 96, 96]を出力 ###########
    # VolPose2dFeatureOnly
    ########################################   
    # Export the model
    #torch.onnx.export(model,               # model being run
    #                  input,                         # model input (or a tuple for multiple inputs)
    #                  "baseline_pose2d_featuresOnly.onnx",   # where to save the model (can be a file or file-like object)
    #                  export_params=True,        # store the trained parameter weights inside the model file
    #                  opset_version=10,          # the ONNX version to export the model to
    #                  do_constant_folding=True,  # whether to execute constant folding for optimization
    #                  input_names = ['input'],   # the model's input names
    #                  output_names = ['features'], # the model's output names
    #                  dynamic_axes={'input' : {0 : 'batch_size'},    # variable lenght axes これで入出力するTensorのdim=0が可変になる。それ以外の次元は固定
    #                                'features' : {0 : 'batch_size'},          #[n, 32, 96, 96]
    #                                })
    #onnx_model = onnx.load("baseline_pose2d_featuresOnly.onnx")
    #onnx.checker.check_model(onnx_model)

    ########################################
    ###### Backboneして2D keypointの取得まで実行するやつ　+ Confidenceも出力  ########### 
    # AlgebraicTriangulationNet2
    ########################################  
    #input = torch.rand(1, 3, 384, 384).to(device)
    #torch.onnx.export(model,               # model being run
    #                  input,                         # model input (or a tuple for multiple inputs)
    #                  "baseline_pose2d_withConfidence2.onnx",   # where to save the model (can be a file or file-like object)
    #                  export_params=True,        # store the trained parameter weights inside the model file
    #                  opset_version=10,          # the ONNX version to export the model to
    #                  do_constant_folding=True,  # whether to execute constant folding for optimization
    #                  input_names = ['input'],   # the model's input names
    #                  output_names = ['joints2d', 'confidence'], # the model's output names
    #                  dynamic_axes={'input' : {0 : 'batch_size'},    # variable lenght axes これで入出力するTensorのdim=0が可変になる。それ以外の次元は固定 # batch_size * 3 * 384 * 384
    #                                'joints2d' : {0 : 'batch_size'}, # batch_size * n_joints * 2
    #                                'confidence' : {0 : 'batch_size'}, # batch_size * n_joints
    #                                })
    #onnx_model = onnx.load("baseline_pose2d_withConfidence2.onnx")
    #onnx.checker.check_model(onnx_model)

    ########################################
    ###### Backboneして2D keypointの取得まで実行するやつ ###########
    # BaselinePose2d
    ########################################  
    #input = torch.rand(1, 3, 384, 384).cpu()
    ## Export the model
    #torch.onnx.export(model,               # model being run
    #                  input,                         # model input (or a tuple for multiple inputs)
    #                  "baseline_pose2d.onnx",   # where to save the model (can be a file or file-like object)
    #                  export_params=True,        # store the trained parameter weights inside the model file
    #                  opset_version=10,          # the ONNX version to export the model to
    #                  do_constant_folding=True,  # whether to execute constant folding for optimization
    #                  input_names = ['input'],   # the model's input names
    #                  output_names = ['joints2d'], # the model's output names
    #                  dynamic_axes={'input' : {0 : 'batch_size'},    # variable lenght axes これで入出力するTensorのdim=0が可変になる。それ以外の次元は固定
    #                                'joints2d' : {0 : 'batch_size'},                                    
    #                                })
    #onnx_model = onnx.load("baseline_pose2d.onnx")
    #onnx.checker.check_model(onnx_model)

    ########################################
    ###### シンプルにBackboneを実行するやつ ###########
    # VolumetricTriangulationNet2
    ########################################   
    #input = torch.rand(1, 3, 384, 384).cuda() #.cpu()
    ## Export the model
    #torch.onnx.export(model.backbone,               # model being run
    #                  input,                         # model input (or a tuple for multiple inputs)
    #                  "onnx_pose2d_gpu.onnx",   # where to save the model (can be a file or file-like object)
    #                  export_params=True,        # store the trained parameter weights inside the model file
    #                  opset_version=10,          # the ONNX version to export the model to
    #                  do_constant_folding=True,  # whether to execute constant folding for optimization
    #                  input_names = ['input'],   # the model's input names
    #                  output_names = ['heatmaps', 'features'], # the model's output names
    #                  dynamic_axes={'input' : {0 : 'batch_size'},    # variable lenght axes これで入出力するTensorのdim=0が可変になる。それ以外の次元は固定
    #                                'heatmaps' : {0 : 'batch_size'},
    #                                'features' : {0 : 'batch_size'},                                    
    #                                })
    #onnx_model = onnx.load("onnx_pose2d_gpu.onnx")
    #onnx.checker.check_model(onnx_model)

    ########################################
    ###### Onnx 測定 ###########
    ########################################    
    #ort_session = onnxruntime.InferenceSession("onnx_pose2d_gpu.onnx")
    # compute ONNX Runtime output prediction
    #ort_inputs = {ort_session.get_inputs()[0].name: to_numpy(input)}
        #print('Normal model inferece')
    #start = time.time()
    #ort_outs = ort_session.run(None, ort_inputs)
    #delta_time = time.time() - start
    #print(delta_time)
    ##///////////////////////////////////////

    print("Done.")


if __name__ == '__main__':
    start = time.time()
    main()
    delta_time = time.time() - start
    print(delta_time)
